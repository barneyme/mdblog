# Welcome.

MD Blog is a simple blogging tool that uses Markdown.

## Summary

The application is contained in the single index.html file. Configuration is done in two simple text files. Blog posts are written in standard Markdown format.

## Why

Why not?

MD Blog is a simple blogging tool that runs on any basic webserver. It is free and easy to set up. Just edit two simple text files and upload MD Blog to a web server and you are done.

## Markdown

Markdown is a lightweight markup language that allows people to format plain text using simple syntax. It is widely used for creating structured documents such as README files, documentation, and blog posts, emphasizing readability in its raw form. By utilizing characters like asterisks for bold or italic text and hashtags for header levels, Markdown enables quick and easy formatting without complex coding.
